<?php
/**
 * The template for displaying all category pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package SKT Fitness
 */

get_header(); ?>

<div class="content-area">
    <div class="middle-align content_sidebar">
        <div <?php if(of_get_option('sidebar_pos',true) != 'none') { ?>class="site-main"<?php } ?> id="sitemain" <?php if(of_get_option('sidebar_pos',true) == 'left') { ?> style="float:right;" <?php } ?>>
            <header class="page-header">
				<h1 class="page-title"><?php single_cat_title('Category: '); ?></h1>
            </header><!-- .page-header -->
			<?php if ( have_posts() ) : ?>
				<?php /* Start the Loop */ ?>
                <?php while ( have_posts() ) : the_post(); ?>
                    <?php get_template_part( 'content', get_post_format() ); ?>
                <?php endwhile; ?>
                <?php skt_fitness_pagination(); ?>
            <?php else : ?>
                <?php get_template_part( 'no-results', 'archive' ); ?>
            <?php endif; ?>
        </div>
         <?php if(of_get_option('sidebar_pos',true) != 'none') { ?>
        <?php get_sidebar('blog');?>
        <?php } ?>
        <div class="clear"></div>
    </div>
</div>

<?php get_footer(); ?>