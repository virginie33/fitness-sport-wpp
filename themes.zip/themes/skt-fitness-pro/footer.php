<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package SKT Fitness
 */
?>
  <div class="mentions-légales">
<a href="http://www.monsite.fr/mentions-legales/" target="_blank">Mentions Légales</a></div>
<div class="copyright-wrapper">
              <div class="copyright">
                <div class="copyright-txt">Copyright © 2017,ellipse-fitness</div>
               </div>
            </div>       
            <div class="clear"></div>
        </div>
    </div>

<?php wp_footer(); ?>

</body>
</html>