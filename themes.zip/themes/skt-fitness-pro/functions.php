<?php
/**
 * SKT Fitness functions and definitions
 *
 * @package SKT Fitness
 */

/**
 * Set the content width based on the theme's design and stylesheet.
 */
function content($limit) {
$content = explode(' ', get_the_excerpt(), $limit);
if (count($content)>=$limit) {
array_pop($content);
$content = implode(" ",$content).'...';
} else {
$content = implode(" ",$content);
}	
$content = preg_replace('/\[.+\]/','', $content);
$content = apply_filters('the_content', $content);
$content = str_replace(']]>', ']]&gt;', $content);
return $content;
}

function custom_excerpt_length( $length ) {
	return 100;
}
add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );

if ( ! function_exists( 'skt_fitness_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which runs
 * before the init hook. The init hook is too late for some features, such as indicating
 * support post thumbnails.
 */
function skt_fitness_setup() {

	if ( ! isset( $content_width ) )
		$content_width = 640; /* pixels */

	load_theme_textdomain( 'skt-fitness', get_template_directory() . '/languages' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'woocommerce' );
	add_theme_support( 'title-tag' );
	add_image_size('homepage-thumb',240,145,true);
	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'skt-fitness' ),
		'footer' => __( 'Footer Menu', 'skt-fitness' ),
	) );
	add_theme_support( 'custom-background', array(
		'default-color' => 'ffffff'
	) );
	add_editor_style( 'editor-style.css' );
}
endif; // skt_fitness_setup
add_action( 'after_setup_theme', 'skt_fitness_setup' );


function skt_fitness_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Blog Sidebar', 'skt-fitness' ),
		'description'   => __( 'Appears on blog page sidebar', 'skt-fitness' ),
		'id'            => 'sidebar-1',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
	
	register_sidebar( array(
		'name'          => __( 'Main Sidebar', 'skt-fitness' ),
		'description'   => __( 'Appears on page sidebar', 'skt-fitness' ),
		'id'            => 'sidebar-main',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
	
	register_sidebar( array(
		'name'          => __( 'Footer Widget 1', 'skt-fitness' ),
		'description'   => __( 'Appears on footer', 'skt-fitness' ),
		'id'            => 'footer-1',
		'before_widget' => '<div class="footer-col-1">',
		'after_widget'  => '</div>',
		'before_title'  => '<h2>',
		'after_title'   => '</h2>',
	) );
	
	register_sidebar( array(
		'name'          => __( 'Footer Widget 2', 'skt-fitness' ),
		'description'   => __( 'Appears on footer', 'skt-fitness' ),
		'id'            => 'footer-2',
		'before_widget' => '<div class="footer-col-1">',
		'after_widget'  => '</div>',
		'before_title'  => '<h2>',
		'after_title'   => '</h2>',
	) );
	
	register_sidebar( array(
		'name'          => __( 'Footer Widget 3', 'skt-fitness' ),
		'description'   => __( 'Appears on footer', 'skt-fitness' ),
		'id'            => 'footer-3',
		'before_widget' => '<div class="footer-col-3">',
		'after_widget'  => '</div>',
		'before_title'  => '<h2>',
		'after_title'   => '</h2>',
	) );
	
	register_sidebar( array(
		'name'          => __( 'Footer Widget 4', 'skt-fitness' ),
		'description'   => __( 'Appears on footer', 'skt-fitness' ),
		'id'            => 'footer-4',
		'before_widget' => '<div class="footer-col-2">',
		'after_widget'  => '</div>',
		'before_title'  => '<h2>',
		'after_title'   => '</h2>',
	) );

}
add_action( 'widgets_init', 'skt_fitness_widgets_init' );

define( 'OPTIONS_FRAMEWORK_DIRECTORY', get_template_directory_uri() . '/inc/' );
require_once get_template_directory() . '/inc/options-framework.php';

function skt_fitness_scripts() {
	wp_enqueue_style( 'skt_fitness-gfonts-opensans', '//fonts.googleapis.com/css?family=Open+Sans:400,600,700','',null );
	wp_enqueue_style( 'skt_fitness-gfonts-roboto', '//fonts.googleapis.com/css?family=Roboto:400,100,300,500,700','',null );
	wp_enqueue_style( 'skt_fitness-gfonts-opensanscondensed', '//fonts.googleapis.com/css?family=Open+Sans+Condensed:300','',null );

	if( of_get_option('bodyfontface',true) != '' ){
		wp_enqueue_style( 'skt_fitness-gfonts-body', '//fonts.googleapis.com/css?family='.rawurlencode(of_get_option('bodyfontface',true)).'&subset=cyrillic,arabic,bengali,cyrillic,cyrillic-ext,devanagari,greek,greek-ext,gujarati,hebrew,latin-ext,tamil,telugu,thai,vietnamese,latin' );
	}
	if( of_get_option('logofontface',true) != '' ){
		wp_enqueue_style( 'skt_fitness-gfonts-logo', '//fonts.googleapis.com/css?family='.rawurlencode(of_get_option('logofontface',true)).'&subset=cyrillic,arabic,bengali,cyrillic,cyrillic-ext,devanagari,greek,greek-ext,gujarati,hebrew,latin-ext,tamil,telugu,thai,vietnamese,latin' );
	}
	if ( of_get_option('navfontface', true) != '' ) {
		wp_enqueue_style( 'skt_fitness-gfonts-nav', '//fonts.googleapis.com/css?family='.rawurlencode(of_get_option('navfontface',true)).'&subset=cyrillic,arabic,bengali,cyrillic,cyrillic-ext,devanagari,greek,greek-ext,gujarati,hebrew,latin-ext,tamil,telugu,thai,vietnamese,latin' );
	}
	if ( of_get_option('headfontface', true) != '' ) {
		wp_enqueue_style( 'skt_fitness-gfonts-heading', '//fonts.googleapis.com/css?family='.rawurlencode(of_get_option('headfontface',true)).'&subset=cyrillic,arabic,bengali,cyrillic,cyrillic-ext,devanagari,greek,greek-ext,gujarati,hebrew,latin-ext,tamil,telugu,thai,vietnamese,latin' );
	}
	if ( of_get_option('sldfontface', true) != '' ) {
		wp_enqueue_style( 'skt_fitness-gfonts-slide', '//fonts.googleapis.com/css?family='.rawurlencode(of_get_option('sldfontface',true)).'&subset=cyrillic,arabic,bengali,cyrillic,cyrillic-ext,devanagari,greek,greek-ext,gujarati,hebrew,latin-ext,tamil,telugu,thai,vietnamese,latin' );
	}
	if ( of_get_option('slddscfontface', true) != '' ) {
		wp_enqueue_style( 'skt_fitness-gfonts-slidedsc', '//fonts.googleapis.com/css?family='.rawurlencode(of_get_option('slddscfontface',true)).'&subset=cyrillic,arabic,bengali,cyrillic,cyrillic-ext,devanagari,greek,greek-ext,gujarati,hebrew,latin-ext,tamil,telugu,thai,vietnamese,latin' );
	}
	if ( of_get_option('foottitlefontface', true) != '' ) {
		wp_enqueue_style( 'skt_fitness-gfonts-foottitle', '//fonts.googleapis.com/css?family='.rawurlencode(of_get_option('foottitlefontface',true)).'&subset=cyrillic,arabic,bengali,cyrillic,cyrillic-ext,devanagari,greek,greek-ext,gujarati,hebrew,latin-ext,tamil,telugu,thai,vietnamese,latin');
	}
	if ( of_get_option('copyfontface', true) != '' ) {
		wp_enqueue_style( 'skt_fitness-gfonts-copyfont', '//fonts.googleapis.com/css?family='.rawurlencode(of_get_option('copyfontface',true)).'&subset=cyrillic,arabic,bengali,cyrillic,cyrillic-ext,devanagari,greek,greek-ext,gujarati,hebrew,latin-ext,tamil,telugu,thai,vietnamese,latin' );
	}
	if ( of_get_option('designfontface', true) != '' ) {
		wp_enqueue_style( 'skt_fitness-gfonts-designfont', '//fonts.googleapis.com/css?family='.rawurlencode(of_get_option('designfontface',true)).'&subset=cyrillic,arabic,bengali,cyrillic,cyrillic-ext,devanagari,greek,greek-ext,gujarati,hebrew,latin-ext,tamil,telugu,thai,vietnamese,latin' );
	}

	wp_enqueue_style( 'skt_fitness-basic-style', get_stylesheet_uri() );
	wp_enqueue_style( 'skt_fitness-editor-style', get_template_directory_uri().'/editor-style.css','',null );
	wp_enqueue_style( 'skt_fitness-base-style', get_template_directory_uri().'/css/style_base.css','',null );
	wp_enqueue_style( 'skt_fitness-responsive-style', get_template_directory_uri().'/css/theme-responsive.css','',null );
	if ( is_home() || is_front_page() ) { 
		wp_enqueue_style( 'skt_fitness-nivo-style', get_template_directory_uri().'/css/nivo-slider.css','',null );
		wp_enqueue_script( 'skt_fitness-nivo-slider', get_template_directory_uri() . '/js/jquery.nivo.slider.js', array('jquery'),null,true );
	}
	wp_enqueue_style( 'skt_fitness-prettyphoto-style', get_template_directory_uri().'/css/prettyPhoto.css','',null );
	wp_enqueue_style( 'skt_fitness-fontawesome-style', get_template_directory_uri().'/css/font-awesome.css','',null );
	wp_enqueue_script( 'skt_fitness-prettyphoto-script', get_template_directory_uri() . '/js/jquery.prettyPhoto.js', array('jquery'),null,true );
	wp_enqueue_script( 'skt_fitness-customscripts', get_template_directory_uri() . '/js/custom.js', array('jquery'),null );	
	wp_enqueue_script( 'skt_fitness-filter-scripts', get_template_directory_uri().'/js/filter-gallery.js','',null,true);
	wp_enqueue_style( 'skt_fitness-animation-style', get_template_directory_uri().'/css/animation.css','',null );
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'skt_fitness_scripts' );

function media_css_hook(){
	
	?>
    	
    	<script>		
			jQuery.noConflict();			
			jQuery(window).load(function() {
        	jQuery('#slider').nivoSlider({
        	effect:'<?php echo of_get_option('slideefect',true); ?>', //sliceDown, sliceDownLeft, sliceUp, sliceUpLeft, sliceUpDown, sliceUpDownLeft, fold, fade, random, slideInRight, slideInLeft, boxRandom, boxRain, boxRainReverse, boxRainGrow, boxRainGrowReverse
		  	animSpeed: <?php echo of_get_option('slideanim',true); ?>,
			pauseTime: <?php echo of_get_option('slidepause',true); ?>,
			directionNav: <?php echo of_get_option('slidenav',true); ?>,
			controlNav: <?php echo of_get_option('slidepage',true); ?>,
			pauseOnHover: <?php echo of_get_option('slidepausehover',true); ?>,
    });
});
		</script>
    <?php 
		
	}
add_action('wp_head','media_css_hook');


function skt_fitness_custom_head_codes() { 
	if ( function_exists('of_get_option') ){
		if ( of_get_option('style2', true) != '' ) {
			echo "<style>". esc_html( of_get_option('style2', true) ) ."</style>";
		}
		echo "<style>";
		if ( of_get_option('bodyfontface', true) != '') {
			echo 'body, .top-grey-box, p, .testimonial-section, .feature-box p, .address, #footer .footer-inner p, .right-features .feature-cell .feature-desc, .price-table{font-family:\''. esc_html( of_get_option('bodyfontface', true) ) .'\', sans-serif;}';
		}
		if ( of_get_option('bodyfontcolor', true) != '' ) {
			echo 'body, .contact-form-section .address, .newsletter, .top-grey-box, .testimonial-section .testimonial-box .testimonial-content .testimonial-mid, .right-features .feature-cell, .accordion-box .acc-content, .work-box .work-info, .feature-box{color:'. esc_html( of_get_option('bodyfontcolor', true) ) .';}';
		}
		if( of_get_option('bodyfontsize',true) != ''){
			echo "body{font-size:".of_get_option('bodyfontsize',true)."}";
		}
		if( of_get_option('logofontface',true) != '' || of_get_option('logofontcolor',true) != '' || of_get_option('logofontsize',true) != ''){
			echo ".header .header-inner .logo h1, .logo a{font-family:".of_get_option('logofontface').";color:".of_get_option('logofontcolor',true).";font-size:".of_get_option('logofontsize',true)."}";
		}
		
		if( of_get_option('logotaglinecolor',true) != '' ){
			echo ".logo .tagline{color:".of_get_option('logotaglinecolor',true).";}";
		}
		if ( of_get_option('navfontface', true) != '' || of_get_option('navfontsize',true) != '' ) {
			echo '.header .header-inner .nav ul{font-family:\''. esc_html( of_get_option('navfontface', true) ) .'\', sans-serif;font-size:'.of_get_option('navfontsize',true).'}';
		}
		if ( of_get_option('navfontcolor', true) != '' ) {
			echo '.header .header-inner .nav ul li a, .header .header-inner .nav ul li ul li a{color:'. esc_html( of_get_option('navfontcolor', true) ) .';}';
		}
		if ( of_get_option('navhovercolor', true) != '' ) {
			echo '.header .header-inner .nav ul li a:hover{color:'. esc_html( of_get_option('navhovercolor', true) ) .';}';
		}
		if( of_get_option('navbgcolor',true) != ''){
			echo ".header .header-inner .nav ul li.current_page_item a, .header .header-inner .nav ul li:hover a, .header .header-inner .nav ul li:hover > ul{background-color:".of_get_option('navbgcolor',true)."}";
		}
		if( of_get_option('navbgcolor',true) != ''){
			echo "@media screen and (max-width:999px){.nav ul{background-color:".of_get_option('navbgcolor',true)."}}";
		}
		if( of_get_option('sldfontface',true) != '' || of_get_option('sldtitlecolor') != '' || of_get_option('sldtitlesize',true) != ''){
			echo "#slider .top-bar h2{font-family:".of_get_option('sldfontface',true).";color:".of_get_option('sldtitlecolor',true)."; font-size:".of_get_option('sldtitlesize',true)."}";
		}
		
		if( of_get_option('slddscfontface',true) != '' || of_get_option('slddsccolor',true) != ''){
			echo "#slider .top-bar p{font-family:".of_get_option('slddscfontface',true).";color:".of_get_option('slddsccolor',true)."}";
		}
		if( of_get_option('slddescsize',true) != '' ){
			echo "#slider .top-bar p{font-size:".of_get_option('slddescsize',true)."}";
		}
		if( of_get_option('sectitlesize',true) != '' ){
			echo "h2.section_title{font-size:".of_get_option('sectitlesize',true)."}";
		}
		if ( of_get_option('headfontface', true) != '' || of_get_option('sectitlecolor',true) != '' ) {
			echo 'h1, h2, h3, h4, h5, h6, section h1, .services-box h2, .contact-banner h3, .team-col h3, .newsletter h2{font-family:\''. esc_html( of_get_option('headfontface', true) ) .'\', sans-serif;color:'.of_get_option('sectitlecolor',true).'}';
		}
		if ( of_get_option('linkcolor', true) != '' ) {
			echo 'a{color:'. esc_html( of_get_option('linkcolor', true) ) .';}';
			echo '#slider .top-bar a.read:hover{background-color:'.of_get_option('linkcolor',true).'}';
		}
		if ( of_get_option('linkhovercolor', true) != '' ) {
			echo 'a:hover, .recent-post li a:hover{color:'. esc_html( of_get_option('linkhovercolor', true) ) .';}';
		}
		if( of_get_option('foottitlefontface', true) != ''){
			echo ".footer .footer-col-1 h2, .footer-col-3 h2{font-family:".of_get_option('foottitlefontface', true)."}";
		}
		if( of_get_option('foottitlecolor', true) != ''){
			echo ".footer .footer-col-1 h2, .footer-col-3 h2{color:".of_get_option('foottitlecolor', true)."}";
		}
		if( of_get_option('copyfontface',true) != '' || of_get_option('copycolor', true) != ''){
			echo ".copyright-txt{font-family:".of_get_option('copyfontface',true).";color:".of_get_option('copycolor',true)."}";
		}
		if( of_get_option('designfontface',true) != '' || of_get_option('designcolor', true) != ''){
			echo ".design-by{font-family:".of_get_option('designfontface',true).";color:".of_get_option('designcolor',true)."}";
		}
				
		$hdrhex = of_get_option('headerbgcolor',true); 
		list($r,$g,$b) = sscanf($hdrhex,'#%02x%02x%02x');
		if ( of_get_option('headerbgcolor', true) != '' ) {
			echo ".header{background-color:rgba(".$r.",".$g.",".$b.",".of_get_option('headerbgopacity',true).");}";
		}
		
		$sliderpagerhex = of_get_option('sliderpaginationbg',true); 
		list($r,$g,$b) = sscanf($sliderpagerhex,'#%02x%02x%02x');
		if ( of_get_option('sliderpaginationbg', true) != '' ) {
			echo ".nivo-controlNav{background-color:rgba(".$r.",".$g.",".$b.",".of_get_option('sliderpaginationbgopacity',true).");}";
		}
		
		if ( of_get_option('serbgcolor', true) != '' ) {
			echo '.services-box{border-color:'. esc_html( of_get_option('serbgcolor', true) ) .';}';
		}
		if ( of_get_option('serbghvcolor', true) != '' ) {
			echo '.services-box:hover{border-color:'. esc_html( of_get_option('serbghvcolor', true) ) .';}';
		}
		if ( of_get_option('cntbgcolor', true) != '' ) {
			echo '#slider .top-bar a, .contact-banner a, input.search-submit, .post-password-form input[type=submit]{background-color:'. esc_html( of_get_option('cntbgcolor', true) ) .';}';
		}
		if ( of_get_option('cnthvbgcolor', true) != '' ) {
			echo '#slider .top-bar a:hover, .contact-banner a:hover, input.search-submit:hover, .post-password-form input[type=submit]:hover{background-color:'. esc_html( of_get_option('cnthvbgcolor', true) ) .';}';
		}
		if ( of_get_option('cntfontcolor', true) != '' ) {
			echo '#slider .top-bar a, .contact-banner a{color:'. esc_html( of_get_option('cntfontcolor', true) ) .';}';
		}
		if ( of_get_option('wdgttitleccolor', true) != '' ) {
			echo 'h3.widget-title{color:'. esc_html( of_get_option('wdgttitleccolor', true) ) .';}';
		}
		if ( of_get_option('copybgcolor', true) != '' ) {
			echo '.copyright-wrapper{background-color:'. esc_html( of_get_option('copybgcolor', true) ) .';}';
		}
		if( of_get_option('sldnavbg',true) != ''){
			echo ".nivo-directionNav a{background:url(".get_template_directory_uri()."/images/slide-nav.png) no-repeat scroll 0 0 ".of_get_option('sldnavbg',true).";}";
		}
		if( of_get_option('sldpagebg',true) != ''){
			echo ".nivo-controlNav a{background-color:".of_get_option('sldpagebg',true)."}";
		}
		if( of_get_option('sldpagehvbg',true) != ''){
			echo ".nivo-controlNav a.active{background-color:".of_get_option('sldpagehvbg',true)."}";
		}
		if( of_get_option('footertextcolor',true) != '') { 
			echo ".phone-no strong{color:".of_get_option('footertextcolor',true)."}";
		}
		if( of_get_option('sdrrmborder',true) != '') { 
			echo "#slider .top-bar a.read{border:2px solid ".of_get_option('sdrrmborder',true)."}";
		}		
		if( of_get_option('readmoreborder',true) != '') { 
			echo ".read-more{border:2px solid ".of_get_option('readmoreborder',true)."}";
		}		
		if( of_get_option('readmorebghover',true) != '') { 
			echo ".services-box:hover .read-more{background-color:".of_get_option('readmorebghover',true)."}";
		}
		if( of_get_option('orangecolor',true) != '') { 
			echo "#slider .top-bar h2 span, .services-box h2 span, h2.section_title span, .footer-col-3 h2 span, .accordion-box h2.active, .latest-news .read-more, .testimonial-box h2, .phone-no strong, .recent-post li span, .office_timing .time_row .day, .time_row .title, .footer-col-2 ul li:hover a, .footer-col-2 ul li.current_page_item a, .news-box:hover .post-date, .copyright-txt span, .services-box h4 span{color:".of_get_option('orangecolor',true)."}";
		}
		
		if( of_get_option('orangecolor',true) != '') { 
			echo ".accordion-box h2.active::before, .team-col:hover, .news .newsthumb, .post-date, #commentform input#submit, .wpcf7 form input[type='submit'], .main-form-area input[type='submit']{background-color:".of_get_option('orangecolor',true)."}";
		}
		
		if( of_get_option('orangecolor',true) != '') { 
			echo ".news-box .post-date{border-color:".of_get_option('orangecolor',true)."}";
		}
		
		if( of_get_option('newsbgcolor',true) != '') { 
			echo ".news-box, .latest-news .read-more{background-color:".of_get_option('newsbgcolor',true)."}";
		}
		if( of_get_option('teamsocialbg',true) != '') { 
			echo ".team-col .social-links a{background-color:".of_get_option('teamsocialbg',true)."}";
		}
		
		if( of_get_option('testmonialbxborder',true) != '') { 
			echo ".testimonial-box{border-color:".of_get_option('testmonialbxborder',true)."}";
		}
		
		if( of_get_option('newstitleborder',true) != '') { 
			echo ".news h2, .wpcf7 form input[type='submit'], .main-form-area input[type='submit']{border-color:".of_get_option('newstitleborder',true)."}";
		}
		
		if ( of_get_option('footerbgimg', true) != '' ) {
			echo "#footer-wrapper{background: url(".of_get_option('footerbgimg', true)."); background-repeat:no-repeat; background-position:center center;  background-size:cover;}";
	    }
				
		if ( of_get_option('footerbgcolor', true) != '' && of_get_option('footerbgimg', true) == '' ) {
			echo "#footer-wrapper{background-color:".of_get_option('footerbgcolor', true)."}";
		}
		
		if ( of_get_option('rpborder', true) != '' ) {
			echo ".recent-post li, .office_timing .time_row, .time_table .time_row{border-color:".of_get_option('rpborder', true)."}";
		}
		if( of_get_option('galhvcolor',true) != ''){
			echo ".photobooth .gallery ul li:hover{ background:".of_get_option('galhvcolor',true)."; background:url(".get_template_directory_uri()."/images/camera-icon.png) 50% 50% no-repeat ".of_get_option('galhvcolor',true)."; }";
		}
		if ( of_get_option('logoheight', true) != '' ) {
			echo '.logo img{height:'. esc_html( of_get_option('logoheight', true) ) .'px;}';
		}		
		if ( of_get_option('rpimgborder', true) != '' ) {
			echo '.recent-post li img{border-color:'. esc_html( of_get_option('rpimgborder', true) ) .';}';
		}
		
		if ( of_get_option('togglemenubgcolor', true) != '' || of_get_option('togglemenufontcolor', true) != '') {
			echo '.toggle a{background-color:'. esc_html( of_get_option('togglemenubgcolor', true) ) .'; color:'. esc_html( of_get_option('togglemenufontcolor', true) ) .';}';
		}
		
		
		echo "</style>";
	}
}
add_action('wp_head', 'skt_fitness_custom_head_codes');


function skt_fitness_pagination() {
	global $wp_query;
	$big = 12345678;
	$page_format = paginate_links( array(
	    'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
	    'format' => '?paged=%#%',
	    'current' => max( 1, get_query_var('paged') ),
	    'total' => $wp_query->max_num_pages,
	    'type'  => 'array'
	) );
	if( is_array($page_format) ) {
		$paged = ( get_query_var('paged') == 0 ) ? 1 : get_query_var('paged');
		echo '<div class="pagination"><div><ul>';
		echo '<li><span>'. $paged . ' of ' . $wp_query->max_num_pages .'</span></li>';
		foreach ( $page_format as $page ) {
			echo "<li>$page</li>";
		}
		echo '</ul></div></div>';
	}
}
/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';


/**
 * Load custom functions file.
 */
require get_template_directory() . '/inc/custom-functions.php';


function skt_fitness_custom_blogpost_pagination( $wp_query ){
	$big = 999999999; // need an unlikely integer
	if ( get_query_var('paged') ) { $pageVar = 'paged'; }
	elseif ( get_query_var('page') ) { $pageVar = 'page'; }
	else { $pageVar = 'paged'; }
	$pagin = paginate_links( array(
		'base' 			=> str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
		'format' 		=> '?'.$pageVar.'=%#%',
		'current' 		=> max( 1, get_query_var($pageVar) ),
		'total' 		=> $wp_query->max_num_pages,
		'prev_text'		=> '&laquo; Prev',
		'next_text' 	=> 'Next &raquo;',
		'type'  => 'array'
	) ); 
	if( is_array($pagin) ) {
		$paged = ( get_query_var('paged') == 0 ) ? 1 : get_query_var('paged');
		echo '<div class="pagination"><div><ul>';
		echo '<li><span>'. $paged . ' of ' . $wp_query->max_num_pages .'</span></li>';
		foreach ( $pagin as $page ) {
			echo "<li>$page</li>";
		}
		echo '</ul></div></div>';
	} 
}

// get slug by id
function skt_fitness_get_slug_by_id($id) {
	$post_data = get_post($id, ARRAY_A);
	$slug = $post_data['post_name'];
	return $slug; 
}


// custom post type for testimonial
function my_custom_post_testimonial() {
	$labels = array(
		'name'               => __( 'Testimonial','skt-fitness'),
		'singular_name'      => __( 'Testimonial','skt-fitness'),
		'add_new'            => __( 'Add Testimonial','skt-fitness'),
		'add_new_item'       => __( 'Add New Testimonial','skt-fitness'),
		'edit_item'          => __( 'Edit Testimonial','skt-fitness'),
		'new_item'           => __( 'New Testimonial','skt-fitness'),
		'all_items'          => __( 'All Testimonials','skt-fitness'),
		'view_item'          => __( 'View Testimonial','skt-fitness'),
		'search_items'       => __( 'Search Testimonial','skt-fitness'),
		'not_found'          => __( 'No Testimonial found','skt-fitness'),
		'not_found_in_trash' => __( 'No Testimonial found in the Trash','skt-fitness'), 
		'parent_item_colon'  => '',
		'menu_name'          => 'Testimonial'
	);
	$args = array(
		'labels'        => $labels,
		'description'   => 'Manage Testimonials',
		'public'        => true,
		'menu_icon'		=> 'dashicons-format-quote',
		'menu_position' => null,
		'supports'      => array( 'title', 'editor', 'thumbnail'),
		'has_archive'   => true,
	);
	register_post_type( 'testimonial', $args );	
}
add_action( 'init', 'my_custom_post_testimonial' );

//read more button
function readmore_func( $atts) {
	extract(shortcode_atts(array(	
	'button'	=> '',	
	'links'		=> '',
	'align'		=> '',						
	), $atts));
	$rrow = '<a style="text-align:'.$align.'" class="read-more" href="'.$links.'">'.$button.'</a>';
    return $rrow;
}
add_shortcode( 'readmore-link', 'readmore_func' );

// add shortcode for skills
function skt_fitness_skills($skt_skill_var){
	extract( shortcode_atts(array(
		'title' 	=> 'title',
		'percent'	=> 'percent',
		'bgcolor'	=> 'bgcolor',
	), $skt_skill_var));
	
	return '<div class="skillbar clearfix " data-percent="'.$percent.'%">
			<div class="skillbar-title"><span>'.$title.'</span></div>
			<div class="skill-bg"><div class="skillbar-bar" style="background:'.$bgcolor.'"></div></div>
			<div class="skill-bar-percent">'.$percent.'%</div>
			</div>';
}

add_shortcode('skill','skt_fitness_skills');

// add shortcode for statistics main area
function skt_fitness_stat_main($atts, $stat_main_content = null){

	return '<ul id="some-facts">'.do_shortcode($stat_main_content).'</ul>';
}
add_shortcode('stat_main','skt_fitness_stat_main');

// add shortcode for statistics
function skt_fitness_stat($skt_stat_var, $stat_content = null){
	extract( shortcode_atts(array(
		'value'		=> '',
	), $skt_stat_var));
	
	return '<li><h2>'.$value.'</h2><h5>'.$stat_content.'</h5></li>';
}
add_shortcode('stat','skt_fitness_stat');

remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' ); 