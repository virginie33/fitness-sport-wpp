<style>body, .top-grey-box, p, .testimonial-section, .feature-box p, .address, #footer .footer-inner p, .right-features .feature-cell .feature-desc, .price-table{font-family:'Arimo', sans-serif;}body, .contact-form-section .address, .newsletter, .top-grey-box, .testimonial-section .testimonial-box .testimonial-content .testimonial-mid, .right-features .feature-cell, .accordion-box .acc-content, .work-box .work-info, .feature-box{color:#ffffff;}body{font-size:12px}.header .header-inner .logo h1, .logo a{font-family:Roboto;color:#ffffff;font-size:28px}.logo .tagline{color:#ffffff;}.header .header-inner .nav ul{font-family:'Roboto', sans-serif;font-size:15px}.header .header-inner .nav ul li a, .header .header-inner .nav ul li ul li a{color:#ffffff;}.header .header-inner .nav ul li a:hover{color:#ffffff;}.header .header-inner .nav ul li.current_page_item a, .header .header-inner .nav ul li:hover a, .header .header-inner .nav ul li:hover > ul{background-color:#ff4e1c}@media screen and (max-width:999px){.nav ul{background-color:#ff4e1c}}#slider .top-bar h2{font-family:Roboto;color:#ffffff; font-size:40px}#slider .top-bar p{font-family:Roboto;color:#ffffff}#slider .top-bar p{font-size:16px}h2.section_title{font-size:40px}h1, h2, h3, h4, h5, h6, section h1, .services-box h2, .contact-banner h3, .team-col h3, .newsletter h2{font-family:'Roboto', sans-serif;color:#ffffff}a{color:#ff4e1c;}#slider .top-bar a.read:hover{background-color:#ff4e1c}a:hover, .recent-post li a:hover{color:#ffffff;}.footer .footer-col-1 h2, .footer-col-3 h2{font-family:Roboto}.footer .footer-col-1 h2, .footer-col-3 h2{color:#ffffff}.copyright-txt{font-family:Arimo;color:#ffffff}.design-by{font-family:Arimo;color:#ffffff}.header{background-color:rgba(0,0,0,0.2);}.nivo-controlNav{background-color:rgba(0,0,0,0.6);}.services-box{border-color:#ffffff;}.services-box:hover{border-color:#ff4e1c;}#slider .top-bar a, .contact-banner a, input.search-submit, .post-password-form input[type=submit]{background-color:#ff4e1c;}#slider .top-bar a:hover, .contact-banner a:hover, input.search-submit:hover, .post-password-form input[type=submit]:hover{background-color:#ef4313;}#slider .top-bar a, .contact-banner a{color:#ffffff;}h3.widget-title{color:#ffffff;}.copyright-wrapper{background-color:#272727;}.nivo-directionNav a{background:url(<?php echo get_template_directory_uri(); ?>/images/slide-nav.png) no-repeat scroll 0 0 #cccccc;}.nivo-controlNav a{background-color:#cccccc}.nivo-controlNav a.active{background-color:#ff4e1c}.phone-no strong{color:#ff4e1c}#slider .top-bar a.read{border:2px solid #ff4e1c}.read-more{border:2px solid #ff4e1c}.services-box:hover .read-more{background-color:#ff4e1c}#slider .top-bar h2 span, .services-box h2 span, h2.section_title span, .footer-col-3 h2 span, .accordion-box h2.active, .latest-news .read-more, .testimonial-box h2, .phone-no strong, .recent-post li span, .office_timing .time_row .day, .time_row .title, .footer-col-2 ul li:hover a, .footer-col-2 ul li.current_page_item a, .news-box:hover .post-date, .copyright-txt span, .services-box h4 span{color:#ff4e1c}.accordion-box h2.active::before, .team-col:hover, .news .newsthumb, .post-date, #commentform input#submit, .wpcf7 form input[type='submit'], .main-form-area input[type='submit']{background-color:#ff4e1c}.news-box .post-date{border-color:#ff4e1c}.news-box, .latest-news .read-more{background-color:#ffffff}.team-col .social-links a{background-color:#ffffff}.testimonial-box{border-color:#565555}.news h2, .wpcf7 form input[type='submit'], .main-form-area input[type='submit']{border-color:#eceaeb}#footer-wrapper{background: url(<?php echo get_template_directory_uri(); ?>/images/footer.jpg); background-repeat:no-repeat; background-position:center center;  background-size:cover;}.recent-post li, .office_timing .time_row, .time_table .time_row{border-color:#3b3b3b}.photobooth .gallery ul li:hover{ background:#ff4e1c; background:url(<?php echo get_template_directory_uri(); ?>/images/camera-icon.png) 50% 50% no-repeat #ff4e1c; }.logo img{height:40px;}.recent-post li img{border-color:#2d2d2d;}.toggle a{background-color:#3e3e3e; color:#ffffff;}</style>
<body class="home blog">
    <div class="slider-main">
        <div id="slider" class="nivoSlider">
       		 <img src="<?php echo get_template_directory_uri(); ?>/images/slides/slider1.jpg" alt="" title="#slidecaption1"/>                
        </div>  
        <div id="slidecaption1" class="nivo-html-caption">
   			 <div class="top-bar">
                <h2>Welcome to Fitness <span>Center</span></h2>
                <p>We are passionate about clients results.</p>
                <a class="read" href="#">Read More &raquo;</a>    
    		</div>
         </div>   
  <div class="clear"></div>    
</div><!-- .slider-main -->
<div class="header">
  <div class="header-inner">
    <div class="logo">
    <a href="<?php echo home_url('/');?>">
      <h1>SKT Fitness</h1>
        <span class="tagline">Just another WordPress site</span>
    </a>   
    </div><!-- logo -->
    <div class="toggle"> <a style="display: none;" class="toggleMenu" href="#">Menu</a> </div><!-- toggle -->
    <div class="nav">
      <div class="menu-primary-container">
        <ul id="menu-primary" class="menu">
          <li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item "><a href="<?php echo home_url('/');?>">Home</a></li>
          <li><a href="#">Sample Page</a></li>          
        </ul>
      </div>
    </div>  <!-- nav -->
    <div class="clear"></div>
  </div>  <!-- header-inner --> 
</div><!-- header -->

<section id="whatwedo">
<div class="container">
  <h2 class="section_title">What We Do</h2>          
  <p class="section_desc">We are possionate about our clients results.</p>     	
</div> 
</section><!-- What We Do Section -->

<section id="pageboxes" >
   <div class="container">
                    <div class="services-box ">
            <div class="srvthumb"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/boxthumb1.jpg" alt=""  /></a></div>
             <a href="#"><h4>Services Box1</h4></a>
            <p>Phasellus viverra aliquet magna quis interduming. Sed quis fringilla massa. In ut porttitor felis necing iaculis mi. Proin tempo...</p>
                               <a class="read-more" href="#">Read More</a>                  
			          
         	</div>
			            <div class="services-box ">
            <div class="srvthumb"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/boxthumb2.jpg" alt=""  /></a></div>
             <a href="#"><h4>Services Box2</h4></a>
            <p>Phasellus viverra aliquet magna quis interduming. Sed quis fringilla massa. In ut porttitor felis necing iaculis mi. Proin tempo...</p>
                               <a class="read-more" href="#">Read More</a>                  
			          
         	</div>
			            <div class="services-box last_column">
            <div class="srvthumb"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/boxthumb3.jpg" alt=""  /></a></div>
             <a href="#"><h4>Services Box3</h4></a>
            <p>Phasellus viverra aliquet magna quis interduming. Sed quis fringilla massa. In ut porttitor felis necing iaculis mi. Proin tempo...</p>
                               <a class="read-more" href="#">Read More</a>                  
			          
         	</div>
			
       <div class="clear"></div>
    </div><!-- .container -->
</section><!-- #pageboxes -->

<section style="background-image:url(<?php echo get_template_directory_uri(); ?>/images/about-banner.jpg); background-repeat:no-repeat; background-position: center center; background-size: cover; " id="about" class="menu_page">
    <div class="container">
      <div class="skillarea">
        <div class="shortdesc">
             <h2 class="section_title">About Gym</h2>
             <p class="section_desc">Effective to beautify your body shape.</p>
         </div>
        <div class="one_half  fadeInUp">
          <h3>Introduction</h3>
          <p></p>
          <div>
            <div class="accordion-box">
              <h2 class="active">Vision and Mission</h2>
              <div style="display: block;" class="acc-content">
                <p> <img src="<?php echo get_template_directory_uri(); ?>/images/vision.jpg">Lorem ipsum dolor sit amet, 
                  consectetur adipiscing elit. Nam sit amet sapien nunc. Mauris quis nisi 
                  nec elit ultrices tincidunt facilisis a enim. Cras malesuada euismod 
                  nisi vitae aliquet. Etiam ultrices libero sed mauris ultrices, nec 
                  porttitor enim consequat. Donec gravida, ipsum ut ultrices 
                  luctussagittis.</p>
              </div>
              <div class="clear"></div>
            </div>
            <p></p>
            <div class="accordion-box">
              <h2>GYM Philosophy</h2>
              <div style="display: none;" class="acc-content">
                <p> <img src="<?php echo get_template_directory_uri(); ?>/images/vision.jpg">Lorem ipsum dolor sit amet, 
                  consectetur adipiscing elit. Nam sit amet sapien nunc. Mauris quis nisi 
                  nec elit ultrices tincidunt facilisis a enim. Cras malesuada euismod 
                  nisi vitae aliquet. Etiam ultrices libero sed mauris ultrices, nec 
                  porttitor enim consequat. Donec gravida, ipsum ut ultrices 
                  luctussagittis.</p>
              </div>
              <div class="clear"></div>
            </div>
            <p></p>
            <div class="clear"></div>
          </div>
        </div>
        <div class="one_half  last_column fadeInUp">
          <p></p>
          <h3>Skills</h3>
          <p></p>
          <div class="skillbar clearfix " data-percent="80%">
            <div class="skillbar-title"><span>Aerobics</span></div>
            <div class="skill-bg">
              <div class="skillbar-bar" style="background: rgb(255, 78, 28) none repeat scroll 0% 0%; width: 80%;"></div>
            </div>
            <div class="skill-bar-percent">80%</div>
          </div>
          <div class="skillbar clearfix " data-percent="99%">
            <div class="skillbar-title"><span>Yoga</span></div>
            <div class="skill-bg">
              <div class="skillbar-bar" style="background: rgb(255, 78, 28) none repeat scroll 0% 0%; width: 99%;"></div>
            </div>
            <div class="skill-bar-percent">99%</div>
          </div>
          <div class="skillbar clearfix " data-percent="90%">
            <div class="skillbar-title"><span>Cardio</span></div>
            <div class="skill-bg">
              <div class="skillbar-bar" style="background: rgb(255, 78, 28) none repeat scroll 0% 0%; width: 90%;"></div>
            </div>
            <div class="skill-bar-percent">90%</div>
          </div>
          <div class="skillbar clearfix " data-percent="95%">
            <div class="skillbar-title"><span>Body Building</span></div>
            <div class="skill-bg">
              <div class="skillbar-bar" style="background: rgb(255, 78, 28) none repeat scroll 0% 0%; width: 95%;"></div>
            </div>
            <div class="skill-bar-percent">95%</div>
          </div>
          <div class="skillbar clearfix " data-percent="90%">
            <div class="skillbar-title"><span>Neutrition</span></div>
            <div class="skill-bg">
              <div class="skillbar-bar" style="background: rgb(255, 78, 28) none repeat scroll 0% 0%; width: 90%;"></div>
            </div>
            <div class="skill-bar-percent">90%</div>
          </div>
        </div>
        <p></p>
      </div>
      <!-- middle-align -->
      <div class="clear"></div>
    </div>
    <!-- container --> 
  </section>
  <div class="clear"></div>
  <section style="background-color:#272727; " id="" class="">
    <div class="container">
      <div class="trainers">
         <div class="shortdesc">
             <h2 class="section_title">Our Trainers</h2>

              <p class="section_desc">Be sure that we know to do a lot.</p>
          </div>
        <div class="team-members fadeInDown">
          <div class="team-col "><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/team4.jpg" class="attachment-post-thumbnail wp-post-image" alt="team4" height="351" width="270"></a>
            <div class="pos">
              <h3>Member 4</h3>
              <span>Fitness Trainer</span>
              <div class="social-links"><a href="#" title="linkedin" target="_blank"><i class="fa fa-linkedin fa-lg"></i></a><a href="#" title="flickr" target="_blank"><i class="fa fa-flickr fa-lg"></i></a><a href="#" title="facebook" target="_blank"><i class="fa fa-facebook fa-lg"></i></a><a href="#" title="twitter" target="_blank"><i class="fa fa-twitter fa-lg"></i></a></div>
            </div>
          </div>
          <div class="team-col "><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/team3.jpg" class="attachment-post-thumbnail wp-post-image" alt="team3" height="351" width="270"></a>
            <div class="pos">
              <h3>Member 3</h3>
              <span>Coach</span>
              <div class="social-links"><a href="#" title="behance" target="_blank"><i class="fa fa-behance fa-lg"></i></a><a href="#" title="instagram" target="_blank"><i class="fa fa-instagram fa-lg"></i></a><a href="#" title="pinterest" target="_blank"><i class="fa fa-pinterest fa-lg"></i></a><a href="#" title="facebook" target="_blank"><i class="fa fa-facebook fa-lg"></i></a></div>
            </div>
          </div>
          <div class="team-col "><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/team2.jpg" class="attachment-post-thumbnail wp-post-image" alt="team2" height="351" width="270"></a>
            <div class="pos">
              <h3>Member 2</h3>
              <span>Sr. Trainer</span>
              <div class="social-links"><a href="#" title="linkedin" target="_blank"><i class="fa fa-linkedin fa-lg"></i></a><a href="#" title="youtube" target="_blank"><i class="fa fa-youtube fa-lg"></i></a><a href="#" title="facebook" target="_blank"><i class="fa fa-facebook fa-lg"></i></a><a href="#" title="twitter" target="_blank"><i class="fa fa-twitter fa-lg"></i></a></div>
            </div>
          </div>
          <div class="team-col last"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/team1.jpg" class="attachment-post-thumbnail wp-post-image" alt="team1" height="351" width="270"></a>
            <div class="pos">
              <h3>Member 1</h3>
              <span>Sr. Instructor</span>
              <div class="social-links"><a href="#" title="facebook" target="_blank"><i class="fa fa-facebook fa-lg"></i></a><a href="#" title="twitter" target="_blank"><i class="fa fa-twitter fa-lg"></i></a><a href="#" title="linkedin" target="_blank"><i class="fa fa-linkedin fa-lg"></i></a><a href="#" title="pinterest" target="_blank"><i class="fa fa-pinterest fa-lg"></i></a></div>
            </div>
          </div>
          <div class="clear"></div>
          <div class="clear"></div>
        </div>
      </div>
      <!-- middle-align -->
      <div class="clear"></div>
    </div>
    <!-- container --> 
  </section>
  <div class="clear"></div>
  <section style="background-image:url(<?php echo get_template_directory_uri(); ?>/images/post-banner.jpg); background-repeat:no-repeat; background-position: center center; background-size: cover; " id="news" class="menu_page">
    <div class="container">
      <div class="latest-news">
       <div class="shortdesc">
          <h2 class="section_title">Latest News</h2>
          <p class="section_desc"> Latest from the blog </p>
        </div>
        <p><a style="text-align:right" class="read-more" href="#">View All</a></p>
        <div class="news-box   fadeInDown">
          <div class="news">
            <div class="newsthumb"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/post2.jpg" alt=" "></a></div>
            <div class="post-right">
              <h2><a href="#">Lorem Ipsum1</a></h2>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam sit amet sapien nunc. Mauris…</p>
              <div class="post-date">31<span>Jul</span></div>
            </div>
          </div>
        </div>
        <div class="news-box   fadeInDown">
          <div class="news">
            <div class="newsthumb"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/post2.jpg" alt=" "></a></div>
            <div class="post-right">
              <h2><a href="#">Hello world!</a></h2>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam sit amet sapien nunc. Mauris…</p>
              <div class="post-date">31<span>Jul</span></div>
            </div>
          </div>
        </div>
        <div class="clear"></div>
        <div class="clear"></div>
        <p></p>
      </div>
      <!-- middle-align -->
      <div class="clear"></div>
    </div>
    <!-- container --> 
  </section>
  <div class="clear"></div>
  <section style="background-color:#272727; " id="testimonials" class="menu_page">
    <div class="container">
      <div class="testimonial">
        <div class="shortdesc">
          <h2 class="section_title">Client Testimonials</h2>
           <p class="section_desc"> Effective to beautify your body shape.</p>
         </div>
        <div class="testimonial-box  fadeInUp"><img src="<?php echo get_template_directory_uri(); ?>/images/team3.jpg" class="attachment-82x82 wp-post-image" alt="team3" height="82" width="82">
          <div class="testimonial-post">
            <p></p>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam 
              sit amet sapien nunc. Mauris quis nisi nec elit ultrices tincidunt 
              facilisis a enim. Cras malesuada euismod nisi vitae aliquet. Etiam 
              ultrices libero sed mauris ultrices, nec porttitor enim consequat</p>
            <p></p>
            <h2>Mary</h2>
          </div>
        </div>
        <div class="testimonial-box last fadeInUp"><img src="<?php echo get_template_directory_uri(); ?>/images/post2.jpg" class="attachment-82x82 wp-post-image" alt="post2" height="82" width="82">
          <div class="testimonial-post">
            <p></p>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam 
              sit amet sapien nunc. Mauris quis nisi nec elit ultrices tincidunt 
              facilisis a enim. Cras malesuada euismod nisi vitae aliquet. Etiam 
              ultrices libero sed mauris ultrices, nec porttitor enim consequat</p>
            <p></p>
            <h2>Rick</h2>
          </div>
        </div>
        <div class="clear"></div>
      </div>
      <!-- middle-align -->
      <div class="clear"></div>
    </div>
    <!-- container --> 
  </section>
  <div class="clear"></div>
  <div id="footer-wrapper">
    <footer class="footer">
      <div class="widget-column-1">
        <div class="footer-col-1">
          <h2>Opening <span>Hours</span></h2>
          <div class="office_timing">
            <div class="time_row"><i class="fa fa-clock-o"></i><span class="day">Monday-Friday</span><span class="start_time">8:00am - 6:00pm</span></div>
            <div class="time_row"><i class="fa fa-clock-o"></i><span class="day">Saturday</span><span class="start_time"> 1:30am - 6:00pm</span></div>
            <div class="time_row"><i class="fa fa-clock-o"></i><span class="day">Sunday</span><span class="start_time">Closed</span></div>
            <div class="clear"></div>
          </div>
        </div>
      </div>
      <div class="widget-column-2">
        <div class="footer-col-2">
          <h2>Quick <span>Links</span></h2>
          <div class="menu">
            <ul>
              <li class="current_page_item"><a href="#">Home</a></li>
              <li class="page_item page-item-24"><a href="#">About Us</a></li>
              <li class="page_item page-item-27"><a href="#">Blog</a></li>
              <li class="page_item page-item-31"><a href="#">Blog Full Width</a></li>
              <li class="page_item page-item-29"><a href="#">Blog Left Sidebar</a></li>
              <li class="page_item page-item-33"><a href="#">Contact Us</a></li>
              <li class="page_item page-item-36"><a href="#">Gallery</a></li>
              <li class="page_item page-item-2"><a href="#">Sample Page</a></li>
              <li class="page_item page-item-52"><a href="#">Shortcodes</a></li>
            </ul>
          </div>
        </div>
      </div>
      <div class="widget-column-1">
        <div class="footer-col-1">
          <h2>Recent <span>Posts</span></h2>
          <ul class="recent-post">
            <li><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/post2.jpg" class="attachment-67x49 wp-post-image" alt="post2" height="49" width="49"></a>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam…</p>
              <a href="#"><span>Read more...</span></a></li>
            <li><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/post2.jpg" class="attachment-67x49 wp-post-image" alt="post2" height="49" width="49"></a>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam…</p>
              <a href="#"><span>Read more...</span></a></li>
          </ul>
        </div>
      </div>
      <div class="widget-column-3">
        <div class="footer-col-3">
          <h2>Fitness <span>Center</span></h2>
          <p>Street 238,52 tempor Donec ultricies mattis nulla, suscipit risus tristique ut.</p>
          <div class="phone-no">
            <p><strong>Phone:</strong>+1 500 000 0000</p>
            <p><strong>E-mail:</strong><a href="mailto:demo@lorem.com">demo@lorem.com</a></p>
            <p><strong>Website:</strong><a href="http://demo.com/" target="_blank">http://demo.com</a></p>
          </div>
        </div>
      </div>
      <div class="clear"></div>
    </footer>
    <div class="copyright-wrapper">
      <div class="copyright">
        <div class="copyright-txt">© 2015 <span>Fitness Center</span>. All Rights Reserved</div>
        <div class="design-by">Design by <a target="_blank" href="http://www.sktthemes.net/">SKT  Themes</a></div>
      </div>
      <div class="clear"></div>
    </div>
  </div>
</body>
</html>