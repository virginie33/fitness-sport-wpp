jQuery(document).ready(function(e) {
    jQuery('.accordion-section-title').eq(0).after('<span style="position:relative; left:5px; top:2px; padding:2px; background-color:#ff4e1c; color:#ffffff; font-weight:bold; line-height:22px;">Check Appearance > Theme Options for Pro Settings</span>');
	jQuery('.accordion-section-title').eq(0).css('padding-bottom','15px', 'padding-top','15px');
});



 
