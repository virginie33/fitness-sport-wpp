<?php if ( is_home() || is_front_page() ) { ?>

<section id="whatwedo">
<div class="container">
	 <?php if( of_get_option('whatwedotitle', true) != '' ){ ?>
            <h2 class="section_title"><?php echo of_get_option('whatwedotitle', true); ?></h2>
     <?php } ?>     
     <?php if( of_get_option('whatwedodescription', true) != '' ){ ?>
            <p class="section_desc"><?php echo of_get_option('whatwedodescription', true); ?></p>
     <?php } ?>	
</div> 
</section><!-- What We Do Section -->


<section id="pageboxes" <?php if( of_get_option('hidethreebxsec', true) != '' ) { ?>style="display:none"<?php } ?>>
   <div class="container">
        <?php
			$boxArr = array();
			 if( of_get_option('box1',true) != '' ){
			  $boxArr[] = of_get_option('box1',false);
			 }
			 if( of_get_option('box2',true) != '' ){
			  $boxArr[] = of_get_option('box2',false);
			 }
			 if( of_get_option('box3',true) != '' ){
			  $boxArr[] = of_get_option('box3',false);
			 }
			 if( of_get_option('box4',true) != '' ){
			  $boxArr[] = of_get_option('box4',false);
			 }
			 if( of_get_option('box5',true) != '' ){
			  $boxArr[] = of_get_option('box5',false);
			 }
			 if( of_get_option('box6',true) != '' ){
			  $boxArr[] = of_get_option('box6',false);
			 }
			
			
			if (!array_filter($boxArr)) {
			for($fx=1; $fx<=3; $fx++) {
			?>
            <div class="services-box <?php if($fx % 3 == 0) { echo "last_column"; } ?>">
            <div class="srvthumb"><a href="#"><img src="<?php  echo esc_url( get_template_directory_uri() ); ?>/images/boxthumb<?php echo $fx; ?>.jpg" alt=""  /></a></div>
             <a href="#"><h4><?php _e('Services Box', 'skt-fitness') ?><?php echo $fx; ?></h4></a>
            <p><?php _e('Phasellus viverra aliquet magna quis interduming. Sed quis fringilla massa. In ut porttitor felis necing iaculis mi. Proin tempo...', 'skt-fitness') ?></p>
             <?php if( of_get_option('threecolreadmorebutton',true) !== '') { ?>
                  <a class="read-more" href="#"><?php echo of_get_option('threecolreadmorebutton'); ?></a>                  
			<?php } ?>
          
         	</div>
			<?php 
			} 
			} else {
				$box_column = array('no_column','one_column','two_column','three_column','four_column','five_column','six_column');
				$fx = 1;
				$queryvar = new wp_query(array('post_type' => 'page', 'post__in' => $boxArr, 'posts_per_page' => 6, 'orderby' => 'post__in' ));		
				while( $queryvar->have_posts() ) : $queryvar->the_post(); ?> 
        	    <div class="services-box <?php echo $box_column[count($boxArr)]; ?> <?php if($fx % count($boxArr) == 0) { echo "last_column"; } ?>">
				  <?php if( of_get_option('boximg'.$fx,true) != '') { ?>	 
                 <div class="srvthumb"><a href="<?php the_permalink(); ?>">
                   <img alt="" src="<?php echo esc_url( of_get_option( 'boximg'.$fx, true )); ?>" / ></a>
                 </div>
                 <?php } ?>
                 <a href="<?php the_permalink(); ?>"> <h4><?php the_title(); ?></h4></a>
                  <?php echo content( of_get_option('servicesbxexcerptlength') ); ?>
                                    
				  <?php if( of_get_option('threecolreadmorebutton',true) !== '') { ?>
                  <a class="read-more" href="<?php the_permalink(); ?>"><?php echo of_get_option('threecolreadmorebutton'); ?></a>                  
				  <?php } ?>
        	   </div>
             <?php 
			 $fx++; 
			 endwhile;
			 wp_reset_query();
			 }
			 ?>

       <div class="clear"></div>
    </div><!-- .container -->
</section><!-- #pageboxes -->
<?php } ?>