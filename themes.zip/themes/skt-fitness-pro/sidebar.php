<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package SKT Fitness
 */
?>
<div id="sidebar">    
    <?php if ( ! dynamic_sidebar( 'sidebar-main' ) ) : ?>
        <aside id="archives" class="widget">
            <h3 class="widget-title"><?php _e( 'Our Skills', 'skt-fitness' ); ?></h3>
             <?php echo do_shortcode('[skill title="Aerobics" percent="80" bgcolor="#ff4e1c"][skill title="Yoga" percent="99" bgcolor="#ff4e1c"][skill title="Cardio" percent="90" bgcolor="#ff4e1c"][skill title="Body Building" percent="95" bgcolor="#ff4e1c"][skill title="Neutrition" percent="90" bgcolor="#ff4e1c"] '); ?> 
        </aside>
        <aside id="meta" class="widget">
            <h3 class="widget-title"><?php _e( 'Opening Hours', 'skt-fitness' ); ?></h3>
            <?php echo do_shortcode('[office_timing]
[office_time_row day="Monday-Friday" start="8:00am - 6:00pm"]
[office_time_row day="Saturday" start=" 1:30am - 6:00pm"]
[office_time_row day="Sunday" start="Closed"]
[/office_timing]'); ?> 
        </aside>
    <?php endif; // end sidebar widget area ?>
	
</div><!-- #sidebar -->