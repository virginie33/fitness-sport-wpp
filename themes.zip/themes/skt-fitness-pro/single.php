<?php
/**
 * The Template for displaying all single posts.
 *
 * @package SKT Fitness
 */

get_header(); ?>

<div class="content-area">
    <div class="middle-align content_sidebar">
        <div <?php if(of_get_option('sidebar_pos',true) != 'none') { ?>class="site-main"<?php } ?> id="sitemain" <?php if(of_get_option('sidebar_pos',true) == 'left') { ?> style="float:right;" <?php } ?>>
			<?php while ( have_posts() ) : the_post(); ?>
                <?php get_template_part( 'content', 'single' ); ?>
                <?php skt_fitness_content_nav( 'nav-below' ); ?>
                <?php
                // If comments are open or we have at least one comment, load up the comment template
                if ( comments_open() || '0' != get_comments_number() )
                    comments_template();
                ?>
            <?php endwhile; // end of the loop. ?>
        </div>
        <?php if(of_get_option('sidebar_pos',true) != 'none') { ?>
        <?php get_sidebar('blog');?>
        <?php } ?>
        <div class="clear"></div>
    </div>
</div>

<?php get_footer(); ?>